# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
import category_encoders as ce
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor,RandomForestClassifier

print("guns detected")
data = pd.read_csv("D:/Semester 5/B1 CSE3105 Project/Review 1/Chicago_Crimes_2012_to_2017.csv/Chicago_Crimes_2012_to_2017.csv")
print(data.head())
data.drop(data.columns[[0]], axis=1, inplace=True)
data=data.drop(['FBI Code','X Coordinate','Y Coordinate','Latitude','Longitude','Location'],axis=1)
data.head()
data = data.head(1000)
encoder = ce.OrdinalEncoder(cols=['Case Number','IUCR','Date','Description', 'Block', 'Primary Type', 'Location Description',	'Arrest'	,'Domestic'	,'Beat'	,'District',	'Year'	,'Updated On'])
#x=data.drop(columns=['Arrest'])
x=data.iloc[:,[2,3,4,5,7,11,12,13]].values
y=data['Arrest']
data = encoder.fit_transform(data)
x=data.iloc[:,[2,3,4,5,7,11,12,13]].values
y=data['Arrest']
#print(x.head())
           

X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)
#x.head()
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)
# create regressor object
model = RandomForestClassifier(n_estimators = 10)
# fit the regressor with x and y data
model.fit(X_train, y_train)
y_pred = model.predict(X_test) 
print("Confusion Matrix: ",confusion_matrix(y_test, y_pred))
print("Accuracy : ",accuracy_score(y_test,y_pred)*100)
print("Report : ",classification_report(y_test, y_pred))







