import numpy as np
import pandas as pd
import seaborn as sea
import matplotlib.pyplot as plt
data = pd.read_csv("D:\Semester 5\L39+L40 CSE3105 Lab\EXP 2\crime_train.csv")
print(data.head())
a=input()
print(a)