import pandas as pd
data=pd.read_csv("C:/Users/Gnanabharathi/Downloads/Iris.csv")
print(data.head)